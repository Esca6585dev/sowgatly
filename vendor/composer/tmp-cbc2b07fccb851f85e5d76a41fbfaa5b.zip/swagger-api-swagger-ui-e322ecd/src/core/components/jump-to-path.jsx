import React from "react"

// Nothing by default- component can be overridden by another plugin.

export default class JumpToPath extends React.Component {
  render() {
    return null
  }
}

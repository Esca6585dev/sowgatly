<?php

namespace Maatwebsite\Excel\Concerns;

interface WithGroupedHeadingRow extends WithHeadingRow
{
}
